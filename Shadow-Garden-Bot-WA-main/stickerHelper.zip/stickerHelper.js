const sharp = require('sharp');
const ffmpeg = require('fluent-ffmpeg');
const { tmpdir } = require('os');
const { join } = require('path');
const { writeFile, readFile, unlink } = require('fs/promises');
const { randomBytes } = require('crypto');

const PACK_NAME   = 'Atomic';
const PACK_AUTHOR = 'Konosuba';

/**
 * Main Entry Point
 * @param {Buffer} inputBuffer 
 * @param {boolean} isVideo - Pass true if the buffer is a video file
 */
async function makeSticker(inputBuffer, isVideo = false) {
  let webp;

  if (isVideo) {
    webp = await convertVideoToWebp(inputBuffer);
  } else {
    webp = await sharp(inputBuffer, { animated: true })
      // Use transparent white (r:255, g:255, b:255, alpha:0) instead of black to prevent alpha bleeding bugs
      .resize(512, 512, { fit: 'contain', background: { r: 255, g: 255, b: 255, alpha: 0 } })
      // Lower quality and increase compression effort. WhatsApp fails to render previews for heavy GIFs
      .webp({ quality: 50, effort: 6 }) 
      .toBuffer();
  }

  return injectMetadata(webp, PACK_NAME, PACK_AUTHOR);
}

// Handles video-to-webp conversion via temporary files
async function convertVideoToWebp(mediaBuffer) {
  const tempIn = join(tmpdir(), `${randomBytes(6).toString('hex')}.mp4`);
  const tempOut = join(tmpdir(), `${randomBytes(6).toString('hex')}.webp`);

  await writeFile(tempIn, mediaBuffer);

  return new Promise((resolve, reject) => {
    ffmpeg(tempIn)
      .inputOptions(['-t 5']) // HARD CAP at 5 seconds. >6s causes WhatsApp preview generation to give up
      .outputOptions([
        '-vcodec libwebp',
        // Force 15 fps. High framerates crash the WhatsApp sticker preview cache
        '-vf scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0.0',
        '-loop 0',
        '-preset default',
        '-an', 
        '-vsync 0',
        '-qscale 50',          // Aggressive compression to keep file size under ~500KB
        '-compression_level 6' 
      ])
      .toFormat('webp')
      .save(tempOut)
      .on('end', async () => {
        const buffer = await readFile(tempOut);
        await Promise.all([unlink(tempIn), unlink(tempOut)]);
        resolve(buffer);
      })
      .on('error', (err) => reject(err));
  });
}

function parseChunks(webpBuf) {
  const chunks = [];
  let pos = 12;
  while (pos + 8 <= webpBuf.length) {
    const id = webpBuf.subarray(pos, pos + 4).toString('binary');
    const size = webpBuf.readUInt32LE(pos + 4);
    const data = Buffer.from(webpBuf.subarray(pos + 8, pos + 8 + size));
    chunks.push({ id, data });
    pos += 8 + size + (size & 1);
  }
  return chunks;
}

function getCanvasSize(chunks) {
  const vp8x = chunks.find(c => c.id === 'VP8X');
  if (vp8x && vp8x.data.length >= 10) {
    return {
      w: vp8x.data.readUIntLE(4, 3) + 1,
      h: vp8x.data.readUIntLE(7, 3) + 1,
    };
  }
  return { w: 512, h: 512 };
}

function buildExifPayload(packName, author) {
  const json = JSON.stringify({
    'sticker-pack-id': 'com.shadowgarden.atomic',
    'sticker-pack-name': packName,
    'sticker-pack-publisher': author,
    'emojis': ['🖤'],
  });
  const jsonBuf = Buffer.from(json, 'utf8');
  const TIFF_HDR = 8;
  const dataOffset = TIFF_HDR + 2 + (1 * 12) + 4;
  const tiff = Buffer.alloc(dataOffset + jsonBuf.length + 1, 0);
  
  tiff.write('II', 0);
  tiff.writeUInt16LE(0x002A, 2);
  tiff.writeUInt32LE(TIFF_HDR, 4);
  tiff.writeUInt16LE(1, 8); 
  tiff.writeUInt16LE(0x010E, 10);
  tiff.writeUInt16LE(2, 12);
  tiff.writeUInt32LE(jsonBuf.length + 1, 14);
  tiff.writeUInt32LE(dataOffset, 18);
  jsonBuf.copy(tiff, dataOffset);
  
  return Buffer.concat([Buffer.from('Exif\x00\x00', 'binary'), tiff]);
}

function serializeChunk(id, data) {
  const idBuf = Buffer.from(id, 'binary');
  const szBuf = Buffer.alloc(4);
  szBuf.writeUInt32LE(data.length, 0);
  const pad = data.length & 1 ? Buffer.from([0]) : Buffer.alloc(0);
  return Buffer.concat([idBuf, szBuf, data, pad]);
}

function injectMetadata(webpBuf, packName, author) {
  const chunks = parseChunks(webpBuf);
  const { w, h } = getCanvasSize(chunks);
  const exifData = buildExifPayload(packName, author);

  let flags = 0x08; 
  const existingVP8X = chunks.find(c => c.id === 'VP8X');
  if (existingVP8X) flags |= existingVP8X.data.readUInt32LE(0);

  const vp8xData = Buffer.alloc(10, 0);
  vp8xData.writeUInt32LE(flags, 0);
  vp8xData.writeUIntLE(w - 1, 4, 3);
  vp8xData.writeUIntLE(h - 1, 7, 3);

  const EXCLUDED = ['VP8X', 'EXIF'];
  const preservedChunks = chunks.filter(c => !EXCLUDED.includes(c.id));

  const body = Buffer.concat([
    Buffer.from('WEBP'),
    serializeChunk('VP8X', vp8xData),
    ...preservedChunks.map(c => serializeChunk(c.id, c.data)),
    serializeChunk('EXIF', exifData),
  ]);

  const riffHeader = Buffer.alloc(8);
  riffHeader.write('RIFF', 0);
  riffHeader.writeUInt32LE(body.length, 4);

  return Buffer.concat([riffHeader, body]);
}

module.exports = { makeSticker };
